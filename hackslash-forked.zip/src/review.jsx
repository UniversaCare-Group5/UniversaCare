import React from "react";
import ReactDOM from "react-dom";
import { makeStyles } from "@material-ui/core/styles";
import { Grid, Paper } from "@material-ui/core";

const useStyles = makeStyles((theme) => ({
  grid: {
    width: "100%",
    margin: "0px"
  },
  paper: {
    padding: theme.spacing(2),
    textAlign: "center",
    color5: theme.palette.text.secondary,
    background: theme.palette.success.light
  }
}));

function Review() {
  const classes = useStyles();
  return (
    <Grid container spacing={2} className={classes.grid} id="review">
      <Grid item xs={12} md={3}>
        <div >
          <h1>5.0</h1>
        <p>2,054 verified customers<br> reviews by Google.</p>
        </div>
      </Grid>

      <Grid item xs={12} md={3}>
        <div className="note">
          <h1 className="note-h1">Title</h1>
          <p className="note-p">content</p>
        </div>
      </Grid>
    </Grid>
  );
}

export default Review;
